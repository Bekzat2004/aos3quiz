 
# Instruction

For running this program you should install compilator of python language. In example below PyCharm will be used:

## Steps

- Open compilator
- Paste code
- Press Run
![Screenshot](img.png)



