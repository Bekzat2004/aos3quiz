import platform
import psutil
import os
import socket
import time
from colorama import init, Fore, Style

def get_disk_info():
    try: # Starting error handling
        disk_usage = psutil.disk_usage('/')
        memory_gb = round(disk_usage.total / (1024 ** 3), 2) # Finding total amount of disk space
        available_disk_space_gb = round(disk_usage.free / (1024 ** 3), 2) # Finding amount of disk space not used
        return memory_gb, available_disk_space_gb
    except PermissionError: # If there are problems with permission print Errors
        print(f"{Fore.RED}Error: Permission denied.{Style.RESET_ALL}")
        return None, None

def get_running_processes(): # Function for finding running processes with error handling
    try:
        running_processes = psutil.process_iter()
        processes_info = [(p.pid, p.name(), round(p.memory_info().rss / (1024 ** 2), 2)) for p in running_processes]
        return processes_info
    except Exception as e:
        print(f"{Fore.RED}An error occurred while retrieving running processes: {e}{Style.RESET_ALL}")
        return None

def get_disk_partitions():
    try:
        partitions = psutil.disk_partitions()
        disk_partitions_info = [(partition.device, partition.mountpoint) for partition in partitions]
        return disk_partitions_info
    except Exception as e:
        print(f"{Fore.RED}An error occurred while retrieving disk partitions: {e}{Style.RESET_ALL}")
        return None

def get_system_architecture():
    try:
        architecture = platform.architecture()[0]
        return architecture
    except Exception as e:
        print(f"{Fore.RED}An error occurred while retrieving system architecture: {e}{Style.RESET_ALL}")
        return None

def get_environment_variables():
    try:
        env_variables = dict(os.environ)
        return env_variables
    except Exception as e:
        print(f"{Fore.RED}An error occurred while retrieving environment variables: {e}{Style.RESET_ALL}")
        return None

if __name__ == "__main__":
    init()  # Initialize colorama for cross-platform colored output
    memory_gb, available_disk_space_gb = get_disk_info()
    processes_info = get_running_processes()
    disk_partitions_info = get_disk_partitions()
    architecture = get_system_architecture()
    env_variables = get_environment_variables()
    if memory_gb is not None and available_disk_space_gb is not None:  # If there is handled error not printing OS description
        print(f"{Fore.BLUE}System Information{Style.RESET_ALL}")
        print(f"{'-' * 20}")
        print(f"{Fore.GREEN}OS Name:{Style.RESET_ALL} {platform.system()}")
        print(f"{Fore.GREEN}OS Version:{Style.RESET_ALL} {platform.release()}")
        print(f"{Fore.GREEN}Processor Information:{Style.RESET_ALL} {platform.processor()}")
        print(f"{Fore.GREEN}Memory (GB):{Style.RESET_ALL} {memory_gb}")
        print(f"{Fore.GREEN}Available Disk Space (GB):{Style.RESET_ALL} {available_disk_space_gb}")
        try:  # Handling error with retrieving current user
            print(f"{Fore.GREEN}Current User:{Style.RESET_ALL} {os.getlogin()}")
        except Exception as e:
            print(f"{Fore.RED}Unable to retrieve current user: {e}{Style.RESET_ALL}")
        print(f"{Fore.GREEN}IP Address:{Style.RESET_ALL} {socket.gethostbyname(socket.gethostname())}")
        print(f"{Fore.GREEN}System Uptime (seconds):{Style.RESET_ALL} {round(time.time() - psutil.boot_time())}")
        print(f"{Fore.GREEN}CPU Usage (%):{Style.RESET_ALL} {psutil.cpu_percent(interval=1)}")
        if processes_info is not None: # Checking if there is error whlie starting fucntion get_running_processes()
            print(f"{Fore.BLUE}Running Processes{Style.RESET_ALL}")
            print(f"{'-' * 20}")
            print(f"{'PID':<10}{'Name':<40}{'Memory Usage (MB)'}")
            for pid, name, mem_usage in processes_info: # Loop for output each running process
                print(f"{pid:<10}{name:<40}{mem_usage}")
        print(f"{Fore.BLUE}System Information{Style.RESET_ALL}")
        print(f"{'-' * 20}")
        print(f"{Fore.GREEN}Disk Partitions:{Style.RESET_ALL}")
        for device, mountpoint in disk_partitions_info: # Loop for output each disk part
            print(f"{Fore.GREEN}  Device:{Style.RESET_ALL} {device}")
            print(f"{Fore.GREEN}  Mountpoint:{Style.RESET_ALL} {mountpoint}")
        print(f"{Fore.GREEN}System Architecture:{Style.RESET_ALL} {architecture}")
        print(f"{Fore.GREEN}Environment Variables:{Style.RESET_ALL}")
        for key, value in env_variables.items(): # Loop for output each environment variable
            print(f"{Fore.GREEN}  {key}:{Style.RESET_ALL} {value}")